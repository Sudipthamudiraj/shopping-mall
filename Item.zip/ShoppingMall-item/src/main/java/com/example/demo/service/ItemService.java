package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Item;

public interface ItemService {

	public Item saveItem(Item item);

	public List<Item> fetchItemList();

	public Item updateItem(Long id, Item item);

	public void deleteItemById(long id);

}
