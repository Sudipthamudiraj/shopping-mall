package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Item;
import com.example.demo.service.ItemService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;




@RestController
public class ItemController {
@Autowired
private ItemService itemService;
@PostMapping("/itemdb")
public Item saveItem(@RequestBody Item item) {
    //TODO: process POST request
    
    return itemService.saveItem(item);
}
@GetMapping("/itemdb")
public List<Item> fetchItemList() {
    return itemService.fetchItemList();
}
@PutMapping("/itemdb/{Id}")
public Item updateItem(@PathVariable("id") Long Id, @RequestBody Item item) {
    //TODO: process PUT request
    return itemService.updateItem(Id, item);
}
@DeleteMapping("/itemdb/{Id}")
public String deleteItemById(@PathVariable("Id") long id) {
	itemService.deleteItemById(id);
	return "Items deleted successfully";
}
}
