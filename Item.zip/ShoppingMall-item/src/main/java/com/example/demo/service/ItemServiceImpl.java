package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.Item;
import com.example.demo.repository.ItemRepository;

@Service
public class ItemServiceImpl implements ItemService{
@Autowired
private ItemRepository itemRepository;

@Override
public Item saveItem(Item item) {
	// TODO Auto-generated method stub
	return itemRepository.save(item);
}

@Override
public List<Item> fetchItemList() {
	// TODO Auto-generated method stub
	return itemRepository.findAll();
}

@Override
public void deleteItemById(long id) {
	// TODO Auto-generated method stub
	itemRepository.deleteById(id);
}

@Override
public Item updateItem(Long id, Item item) {
	// TODO Auto-generated method stub
	Item t1=itemRepository.findById(id).get();
	
	if(Objects.nonNull(item.getName()) &&
		       !"".equalsIgnoreCase(item.getName())) {
		           t1.setName(item.getName());
		       }
	return itemRepository.save(t1);
}

}
